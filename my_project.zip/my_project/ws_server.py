import asyncio
import websockets

connected = set()

async def handler(websocket):
    print("Client connected.")
    connected.add(websocket)
    try:
        while True:
            msg = await websocket.recv()
            print("Received from client:", msg)
            # Broadcast to all connected clients (optional)
            for conn in connected:
                if conn != websocket:
                    await conn.send(msg)
    except websockets.ConnectionClosed:
        print("Client disconnected.")
    finally:
        connected.remove(websocket)

async def main():
    async with websockets.serve(handler, "localhost", 8765):
        print("WebSocket server started at ws://localhost:8765")
        await asyncio.Future()  # run forever

asyncio.run(main())
