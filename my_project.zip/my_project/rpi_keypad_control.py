import socket
import time
from pad4pi import rpi_gpio
import RPi.GPIO as GPIO

# Keypad setup
KEYPAD = [
    ["1", "2", "3", "A"],
    ["4", "5", "6", "B"],
    ["7", "8", "9", "C"],
    ["*", "0", "#", "D"]
]
ROW_PINS = [22, 18, 2, 3]  # BCM
COL_PINS = [8, 10, 9, 11]  # BCM
factory = rpi_gpio.KeypadFactory()
keypad = factory.create_keypad(keypad=KEYPAD, row_pins=ROW_PINS, col_pins=COL_PINS)

# Socket setup
HOST = '192.168.1.x'  # Replace with your PC IP running Webots
PORT = 3000
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))

key_map = {
    "2": "F",  # Forward
    "8": "B",  # Backward
    "4": "L",  # Left
    "6": "R",  # Right
    "5": "S"   # Stop
}

def handle_key(key):
    command = key_map.get(key, None)
    if command:
        print(f"Sending command: {command}")
        s.sendall(command.encode())

keypad.registerKeyPressHandler(handle_key)

try:
    while True:
        time.sleep(0.1)
except KeyboardInterrupt:
    print("Closing connection")
    s.close()
    GPIO.cleanup()
