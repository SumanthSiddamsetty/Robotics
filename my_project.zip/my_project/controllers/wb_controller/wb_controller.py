from controller import Robot, Camera, DistanceSensor
import websocket
import threading

TIME_STEP = 32
SPEED = 5.0
TURN_SPEED = 3.0

robot = Robot()

# Motors
left_motor = robot.getDevice("left wheel")
right_motor = robot.getDevice("right wheel")
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

# Camera
camera = robot.getDevice("front_camera")
camera.enable(TIME_STEP)

# Distance Sensor
ds_front = robot.getDevice("ds_front")
ds_front.enable(TIME_STEP)

# Shared command dictionary
current_command = {"key": None}
last_command = {"key": None}

# WebSocket message handler
def ws_receiver():
    def on_message(ws, message):
        print("🟢 Received WebSocket message:", message)
        current_command["key"] = message.strip().upper()

    def on_error(ws, error):
        print("WebSocket error:", error)

    def on_close(ws):
        print("WebSocket closed")

    def on_open(ws):
        print("Connected to WebSocket server")

    ws = websocket.WebSocketApp("ws://localhost:9000",
                                on_message=on_message,
                                on_error=on_error,
                                on_close=on_close,
                                on_open=on_open)
    ws.run_forever()

# Start WebSocket listener thread
threading.Thread(target=ws_receiver, daemon=True).start()

# Main loop
while robot.step(TIME_STEP) != -1:
    # Remember last command
    if current_command["key"]:
        last_command["key"] = current_command["key"]
        current_command["key"] = None

    key = last_command["key"]
    left_speed = 0.0
    right_speed = 0.0

    if key == "UP":
        left_speed = SPEED
        right_speed = SPEED
    elif key == "DOWN":
        left_speed = -SPEED
        right_speed = -SPEED
    elif key == "LEFT":
        left_speed = -TURN_SPEED
        right_speed = TURN_SPEED
    elif key == "RIGHT":
        left_speed = TURN_SPEED
        right_speed = -TURN_SPEED
    elif key == "STOP" or key is None:
        left_speed = 0.0
        right_speed = 0.0

    # Debug info
    distance = ds_front.getValue()
    print(f"Distance: {distance:.2f} | Command: {key}")
    print(f"Setting motor speeds: L={left_speed:.2f}, R={right_speed:.2f}")

    # Apply speeds
    left_motor.setVelocity(left_speed)
    right_motor.setVelocity(right_speed)
