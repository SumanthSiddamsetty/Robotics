from controller import Robot, Keyboard, Camera, DistanceSensor

# Constants
TIME_STEP = 32
FORWARD_SPEED = 5.0
TURN_SPEED = 3.0
STOP_DISTANCE = 800.0  # Obstacle threshold in mm

robot = Robot()

# Motors
left_motor = robot.getDevice("left wheel")
right_motor = robot.getDevice("right wheel")
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

# Devices
keyboard = Keyboard()
keyboard.enable(TIME_STEP)

camera = robot.getDevice("front_camera")
camera.enable(TIME_STEP)

ds_front = robot.getDevice("ds_front")
ds_front.enable(TIME_STEP)

# Control state
manual_control = False

# Main loop
while robot.step(TIME_STEP) != -1:
    key = keyboard.getKey()
    distance = ds_front.getValue()

    left_speed = 0.0
    right_speed = 0.0

    print(f"📏 Distance: {distance:.2f} mm | Mode: {'Manual' if manual_control else 'Auto'}")

    if distance < STOP_DISTANCE and not manual_control:
        manual_control = True
        print("🛑 Obstacle ahead! Manual control enabled.")

    elif distance >= STOP_DISTANCE and manual_control and key == -1:
        manual_control = False
        print("✅ Obstacle cleared. Resuming autonomous mode.")

    if manual_control:
        if key == keyboard.LEFT:
            left_speed = -TURN_SPEED
            right_speed = TURN_SPEED
        elif key == keyboard.RIGHT:
            left_speed = TURN_SPEED
            right_speed = -TURN_SPEED
        elif key == keyboard.DOWN:
            left_speed = -FORWARD_SPEED
            right_speed = -FORWARD_SPEED
        elif key == keyboard.UP:
            left_speed = FORWARD_SPEED
            right_speed = FORWARD_SPEED
        else:
            left_speed = 0.0
            right_speed = 0.0
    else:
        left_speed = FORWARD_SPEED
        right_speed = FORWARD_SPEED
        print("🚗 Autonomous driving...")

    left_motor.setVelocity(left_speed)
    right_motor.setVelocity(right_speed)
