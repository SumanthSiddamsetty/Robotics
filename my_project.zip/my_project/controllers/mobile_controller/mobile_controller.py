from controller import Robot
import asyncio
import websockets

TIME_STEP = 32
SPEED = 6.0
TURN_SPEED = 3.5

robot = Robot()

# Get motors
left_motor = robot.getDevice("left wheel")
right_motor = robot.getDevice("right wheel")
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

# Initialize WebSocket
command = "STOP"

async def ws_listener():
    global command
    async def handler(websocket, path):
        global command
        async for msg in websocket:
            command = msg
            print(f"📲 Received from mobile: {command}")
    return await websockets.serve(handler, "localhost", 8766)

async def main_loop():
    global command
    await ws_listener()
    print("✅ WebSocket server started at ws://localhost:8765")

    while True:
        robot.step(TIME_STEP)
        left_speed = 0.0
        right_speed = 0.0

        # Control logic
        if command == "UP":
            left_speed = SPEED
            right_speed = SPEED
        elif command == "DOWN":
            left_speed = -SPEED
            right_speed = -SPEED
        elif command == "LEFT":
            left_speed = -TURN_SPEED
            right_speed = TURN_SPEED
        elif command == "RIGHT":
            left_speed = TURN_SPEED
            right_speed = -TURN_SPEED
        else:  # STOP or unknown
            left_speed = 0.0
            right_speed = 0.0

        print(f"Setting motor speeds: L={left_speed:.2f}, R={right_speed:.2f}")
        left_motor.setVelocity(left_speed)
        right_motor.setVelocity(right_speed)

# Run both loops
asyncio.get_event_loop().run_until_complete(main_loop())
asyncio.get_event_loop().run_forever()
