from controller import Robot, Camera
import socket
import threading

TIME_STEP = 32
SPEED = 5.0
robot = Robot()

# Camera
camera = robot.getDevice("front_camera")
camera.enable(TIME_STEP)

left_motor = robot.getDevice("left wheel")
right_motor = robot.getDevice("right wheel")
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

current_command = "S"

def server():
    global current_command
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("0.0.0.0", 3000))
    s.listen(1)
    print("[Webots] Waiting for Raspberry Pi connection...")
    conn, addr = s.accept()
    print(f"Connected by {addr}")
    while True:
        data = conn.recv(1024)
        if not data:
            break
        current_command = data.decode().strip().upper()
    conn.close()

# Start server thread
threading.Thread(target=server, daemon=True).start()

# Main robot control loop
while robot.step(TIME_STEP) != -1:
    if current_command == "F":
        left_motor.setVelocity(SPEED)
        right_motor.setVelocity(SPEED)
    elif current_command == "B":
        left_motor.setVelocity(-SPEED)
        right_motor.setVelocity(-SPEED)
    elif current_command == "L":
        left_motor.setVelocity(-SPEED / 2)
        right_motor.setVelocity(SPEED / 2)
    elif current_command == "R":
        left_motor.setVelocity(SPEED / 2)
        right_motor.setVelocity(-SPEED / 2)
    elif current_command == "S":
        left_motor.setVelocity(0.0)
        right_motor.setVelocity(0.0)
