from controller import Robot, Keyboard, Camera, DistanceSensor

# Constants
TIME_STEP = 32
SPEED = 5.0
TURN_SPEED = 3.0
STOP_DISTANCE = 500.0  # Adjust this threshold based on testing

# Init robot
robot = Robot()

# Motors
left_motor = robot.getDevice("left wheel")
right_motor = robot.getDevice("right wheel")
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

# Keyboard control
keyboard = Keyboard()
keyboard.enable(TIME_STEP)

# Camera setup
camera = robot.getDevice("front_camera")
camera.enable(TIME_STEP)

# Distance sensor setup
ds_front = robot.getDevice("ds_front")
ds_front.enable(TIME_STEP)

# Main loop
while robot.step(TIME_STEP) != -1:
    key = keyboard.getKey()
    left_speed = 0.0
    right_speed = 0.0

    # Read distance sensor
    distance = ds_front.getValue()
    print(f"DistanceSensor (ds_front) reading: {distance:.2f}")

    if distance < STOP_DISTANCE:
        # Obstacle detected — stop motors
        print("🔴 Obstacle too close! Robot stopped.")
        left_speed = 0.0
        right_speed = 0.0
    else:
        # Manual keyboard control
        if key == keyboard.UP:
            left_speed = SPEED
            right_speed = SPEED
        elif key == keyboard.DOWN:
            left_speed = -SPEED
            right_speed = -SPEED
        elif key == keyboard.LEFT:
            left_speed = -TURN_SPEED
            right_speed = TURN_SPEED
        elif key == keyboard.RIGHT:
            left_speed = TURN_SPEED
            right_speed = -TURN_SPEED

    # Apply speeds to motors
    left_motor.setVelocity(left_speed)
    right_motor.setVelocity(right_speed)
