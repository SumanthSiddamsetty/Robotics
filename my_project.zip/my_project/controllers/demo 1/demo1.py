from controller import Robot

robot = Robot()
TIME_STEP = 32

# Correct motor names
left_motor = robot.getDevice("left wheel")
right_motor = robot.getDevice("right wheel")

left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))

left_motor.setVelocity(2.0)
right_motor.setVelocity(2.0)

while robot.step(TIME_STEP) != -1:
    pass
