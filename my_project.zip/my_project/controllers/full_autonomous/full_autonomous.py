from controller import Robot, Camera, DistanceSensor
import time

# === Constants ===
TIME_STEP = 32
FORWARD_SPEED = 5.0
TURN_SPEED = 3.0
STOP_DISTANCE = 800.0
FLOOR_BRIGHTNESS_THRESHOLD = 70.0
FLOOR_TIMEOUT = 3.0  # seconds

REALIGN_DURATION = 10   # steps (~0.3 sec forward slow)
REALIGN_SPEED = 5.0
PAUSE_DURATION = 8      # steps (~0.25 sec pause before/after)

# === Initialize Robot ===
robot = Robot()

# Motors
left_motor = robot.getDevice("left wheel")
right_motor = robot.getDevice("right wheel")
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

# Distance Sensors
ds_front = robot.getDevice("ds_front")
ds_left = robot.getDevice("ds_left")
ds_right = robot.getDevice("ds_right")

ds_front.enable(TIME_STEP)
ds_left.enable(TIME_STEP)
ds_right.enable(TIME_STEP)

# Camera
camera = robot.getDevice("front_camera")
camera.enable(TIME_STEP)
width = camera.getWidth()
height = camera.getHeight()

# === Helper Function ===
def is_floor_bright(image):
    row = height // 2
    col_start = width // 3
    col_end = 2 * width // 3

    brightness_total = 0
    pixels = 0
    for col in range(col_start, col_end):
        r = camera.imageGetRed(image, width, col, row)
        g = camera.imageGetGreen(image, width, col, row)
        b = camera.imageGetBlue(image, width, col, row)
        brightness = (r + g + b) / 3
        brightness_total += brightness
        pixels += 1

    avg_brightness = brightness_total / pixels if pixels > 0 else 0
    print(f"🧠 Floor brightness: {avg_brightness:.1f}")
    return avg_brightness > FLOOR_BRIGHTNESS_THRESHOLD

# === State Variables ===
floor_lost_time = None
in_backup = False
backup_steps = 0
backup_direction = "spin"
in_realign = False
realign_steps = 0
pause_steps = 0

# === Main Loop ===
while robot.step(TIME_STEP) != -1:
    image = camera.getImage()
    distance_front = ds_front.getValue()
    distance_left = ds_left.getValue()
    distance_right = ds_right.getValue()
    floor_visible = is_floor_bright(image)
    current_time = time.time()

    print(f"📏 Distances - Front: {distance_front:.0f}, Left: {distance_left:.0f}, Right: {distance_right:.0f}")

    # Phase 1: Backup (Turning)
    if in_backup:
        print(f"🔁 Turning {backup_direction}...")

        if backup_direction == "left":
            left_motor.setVelocity(-TURN_SPEED)
            right_motor.setVelocity(TURN_SPEED)
        elif backup_direction == "right":
            left_motor.setVelocity(TURN_SPEED)
            right_motor.setVelocity(-TURN_SPEED)
        else:
            left_motor.setVelocity(-TURN_SPEED)
            right_motor.setVelocity(TURN_SPEED)

        backup_steps -= 1
        if backup_steps <= 0:
            print("✅ Turn complete. Starting realignment...")
            in_backup = False
            in_realign = True
            pause_steps = PAUSE_DURATION  # pause before realign
        continue

    # Phase 2: Realign (Pause + Move Straight)
    if in_realign:
        if pause_steps > 0:
            print("🧘 Pausing before/after alignment...")
            left_motor.setVelocity(0.0)
            right_motor.setVelocity(0.0)
            pause_steps -= 1
        elif realign_steps < REALIGN_DURATION:
            print("↔️ Aligning straight...")
            left_motor.setVelocity(REALIGN_SPEED)
            right_motor.setVelocity(REALIGN_SPEED)
            realign_steps += 1
        else:
            print("🧘 Final pause after alignment.")
            pause_steps = PAUSE_DURATION
            realign_steps = 0
            in_realign = False
        continue

    # Phase 3: Check for obstacle/floor issue
    if distance_front < STOP_DISTANCE or not floor_visible:
        print("⛔ Obstacle or floor missing. Stopping...")
        left_motor.setVelocity(0.0)
        right_motor.setVelocity(0.0)

        if floor_lost_time is None:
            floor_lost_time = current_time
        elif current_time - floor_lost_time > FLOOR_TIMEOUT:
            # Choose best direction
            if distance_left > distance_right + 100:
                backup_direction = "left"
            elif distance_right > distance_left + 100:
                backup_direction = "right"
            else:
                backup_direction = "spin"

            print(f"🔄 Entering backup. Direction: {backup_direction}")
            in_backup = True
            backup_steps = 30
            floor_lost_time = None
    else:
        # Phase 4: Move forward
        print("✅ Path & floor clear. Moving forward.")
        left_motor.setVelocity(FORWARD_SPEED)
        right_motor.setVelocity(FORWARD_SPEED)
        floor_lost_time = None
