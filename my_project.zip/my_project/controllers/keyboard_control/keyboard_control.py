from controller import Robot, Keyboard, Camera, DistanceSensor

TIME_STEP = 32
SPEED = 5.0
TURN_SPEED = 3.0

robot = Robot()

# Motors
left_motor = robot.getDevice("left wheel")
right_motor = robot.getDevice("right wheel")
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

# Keyboard
keyboard = Keyboard()
keyboard.enable(TIME_STEP)

# Camera
camera = robot.getDevice("front_camera")
camera.enable(TIME_STEP)

# Distance Sensor
ds_front = robot.getDevice("ds_front")
ds_front.enable(TIME_STEP)

# Main loop
while robot.step(TIME_STEP) != -1:
    key = keyboard.getKey()
    left_speed = 0.0
    right_speed = 0.0

    # Keyboard control
    if key == keyboard.UP:
        left_speed = SPEED
        right_speed = SPEED
    elif key == keyboard.DOWN:
        left_speed = -SPEED
        right_speed = -SPEED
    elif key == keyboard.LEFT:
        left_speed = -TURN_SPEED
        right_speed = TURN_SPEED
    elif key == keyboard.RIGHT:
        left_speed = TURN_SPEED
        right_speed = -TURN_SPEED

    # Get and print distance sensor reading
    distance = ds_front.getValue()
    print(f"DistanceSensor (ds_front) reading: {distance:.2f}")

    # Set motor speeds
    left_motor.setVelocity(left_speed)
    right_motor.setVelocity(right_speed)
