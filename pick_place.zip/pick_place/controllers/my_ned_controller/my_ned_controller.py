from controller import Robot
import math

robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Define joint names and their limits (in radians)
joint_limits = {
    "joint_1": (-2.8, 2.8),
    "joint_2": (-0.8, 0.8),
    "joint_3": (-1.3, 1.3),
    "joint_4": (-2.0, 2.0),
    "joint_5": (-1.5, 1.5),
    "joint_6": (-2.5, 2.5)
}

# Get motors
motors = {}
for name, limits in joint_limits.items():
    motor = robot.getDevice(name)
    motor.setVelocity(1.0)
    motors[name] = motor

# Step counter for motion
step_counter = 0

while robot.step(timestep) != -1:
    for name, (min_limit, max_limit) in joint_limits.items():
        angle = 1.5 * math.sin(step_counter * 0.01)  # a safe small oscillation
        clamped_angle = max(min(angle, max_limit), min_limit)
        motors[name].setPosition(clamped_angle)
    step_counter += 1
