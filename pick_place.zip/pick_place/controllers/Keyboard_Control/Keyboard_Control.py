from controller import Robot, Keyboard
import math

robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Enable keyboard
keyboard = Keyboard()
keyboard.enable(timestep)

# Joint angle limits (in radians)
joint_limits = {
    "joint_1": (-2.8, 2.8),
    "joint_2": (-0.8, 0.8),
    "joint_3": (-1.3, 1.3),
    "joint_4": (-2.0, 2.0),
    "joint_5": (-1.5, 1.5),
    "joint_6": (-2.5, 2.5)
}

# Current joint positions
joint_positions = {joint: 0.0 for joint in joint_limits}

# Get joint motors
motors = {}
for name in joint_limits:
    motor = robot.getDevice(name)
    motor.setVelocity(1.0)
    motors[name] = motor

# Gripper control (dual motors)
try:
    gripper_left = robot.getDevice("gripper::left")
    gripper_right = robot.getDevice("gripper::right")
    gripper_left.setVelocity(0.02)
    gripper_right.setVelocity(0.02)
    gripper_position = 0.0  # range: -0.01 (closed) to +0.01 (open)
except:
    print("⚠️ Gripper motors not found!")
    gripper_left = None
    gripper_right = None
    gripper_position = 0.0

# Key mapping
key_bindings = {
    ord('Q'): ("joint_1", 0.05),
    ord('A'): ("joint_1", -0.05),
    ord('W'): ("joint_2", 0.05),
    ord('S'): ("joint_2", -0.05),
    ord('E'): ("joint_3", 0.05),
    ord('D'): ("joint_3", -0.05),
    ord('R'): ("joint_4", 0.05),
    ord('F'): ("joint_4", -0.05),
    ord('T'): ("joint_5", 0.05),
    ord('G'): ("joint_5", -0.05),
    ord('Y'): ("joint_6", 0.05),
    ord('H'): ("joint_6", -0.05),
    ord('U'): ("gripper", 0.001),   # Open
    ord('J'): ("gripper", -0.001)   # Close
}

print("🕹️ Niryo Ned Keyboard Controls:")
print(" Q/A - Joint 1")
print(" W/S - Joint 2")
print(" E/D - Joint 3")
print(" R/F - Joint 4")
print(" T/G - Joint 5")
print(" Y/H - Joint 6")
print(" U   - Open gripper")
print(" J   - Close gripper")

# Main control loop
while robot.step(timestep) != -1:
    key = keyboard.getKey()
    if key != -1 and key in key_bindings:
        joint, delta = key_bindings[key]
        if joint == "gripper" and gripper_left and gripper_right:
            gripper_position = max(-0.01, min(0.01, gripper_position + delta))
            gripper_left.setPosition(-gripper_position)
            gripper_right.setPosition(gripper_position)
        elif joint in joint_limits:
            min_limit, max_limit = joint_limits[joint]
            new_pos = joint_positions[joint] + delta
            joint_positions[joint] = max(min(new_pos, max_limit), min_limit)

    # Apply motor positions
    for joint, pos in joint_positions.items():
        motors[joint].setPosition(pos)
