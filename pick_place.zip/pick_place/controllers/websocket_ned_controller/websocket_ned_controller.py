from controller import Robot
import asyncio
import threading
import websockets

TIME_STEP = 32
robot = Robot()

# ✅ Joint setup
joint_names = ["joint_1", "joint_2", "joint_3", "joint_4", "joint_5", "joint_6"]
joints = {}
for name in joint_names:
    motor = robot.getDevice(name)
    motor.setPosition(float('inf'))  # Velocity control
    motor.setVelocity(0.0)
    joints[name] = motor
    print(f"✅ {name} initialized")

# ✅ Gripper motors
left_gripper = robot.getDevice("gripper::left")
right_gripper = robot.getDevice("gripper::right")
gripper_position = 0.0  # Internal gripper value
GRIPPER_MIN = -0.01
GRIPPER_MAX = 0.01
if left_gripper and right_gripper:
    left_gripper.setVelocity(0.02)
    right_gripper.setVelocity(0.02)
    print("✅ Gripper motors initialized")
else:
    print("❌ Gripper motors not found")

# ✅ WebSocket command store
latest_command = None

async def ws_handler(websocket):
    global latest_command
    print("🔵 Client connected")
    try:
        async for message in websocket:
            print(f"📥 Received: {message}")
            latest_command = message
    except websockets.exceptions.ConnectionClosed:
        print("❌ Client disconnected")

async def start_ws_server():
    print("🚀 WebSocket server running at ws://0.0.0.0:8765")
    async with websockets.serve(ws_handler, "0.0.0.0", 8765):
        await asyncio.Future()

# ✅ Start server thread
threading.Thread(target=lambda: asyncio.run(start_ws_server()), daemon=True).start()

# ✅ Main Webots loop
while robot.step(TIME_STEP) != -1:
    if latest_command:
        try:
            if latest_command.startswith("gripper:"):
                delta = float(latest_command.split(":")[1])
                gripper_position += delta
                gripper_position = max(GRIPPER_MIN, min(GRIPPER_MAX, gripper_position))
                if left_gripper and right_gripper:
                    left_gripper.setPosition(-gripper_position)
                    right_gripper.setPosition(gripper_position)
                    print(f"🤏 Gripper → {gripper_position:.4f}")
            else:
                joint, value = latest_command.split(":")
                if joint in joints:
                    pos = float(value)
                    joints[joint].setVelocity(1.0)
                    joints[joint].setPosition(pos)
                    print(f"✅ {joint} → {pos}")
        except Exception as e:
            print(f"❌ Error processing command: {e}")
        latest_command = None
